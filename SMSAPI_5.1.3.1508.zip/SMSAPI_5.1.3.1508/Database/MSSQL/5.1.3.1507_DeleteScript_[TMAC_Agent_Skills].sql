WITH deleteduplicaterows AS (
SELECT AgentID, SkillID, ROW_NUMBER() OVER (
PARTITION BY AgentID,SkillID ORDER BY AgentID) row_num FROM TMAC_Agent_Skills)
--deleting all records which has more than one occurance
DELETE FROM deleteduplicaterows
WHERE row_num > 1


DELETE FROM TMAC_Agent_Skills WHERE AgentID IS NULL
DELETE FROM TMAC_Agent_Skills WHERE SkillID IS NULL