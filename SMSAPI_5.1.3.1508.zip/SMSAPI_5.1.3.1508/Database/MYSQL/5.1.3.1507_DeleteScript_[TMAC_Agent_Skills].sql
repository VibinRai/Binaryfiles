DELETE FROM `TMAC_Agent_Skills`
WHERE concat(AgentID, SkillID) IN (
SELECT concat(AgentID, SkillID) FROM 
(SELECT AgentID, SkillID, ROW_NUMBER() OVER (
PARTITION BY AgentID,SkillID ORDER BY AgentID) row_num FROM `TMAC_Agent_Skills`)t
WHERE row_num>1)
LIMIT 1;